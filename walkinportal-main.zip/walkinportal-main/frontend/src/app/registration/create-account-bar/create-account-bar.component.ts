import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-account-bar',
  templateUrl: './create-account-bar.component.html',
  styleUrls: ['./create-account-bar.component.scss']
})
export class CreateAccountBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
